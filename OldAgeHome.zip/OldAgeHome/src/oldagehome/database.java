/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oldagehome;

/**
 *
 * @author DELL
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;



public class database {
    Connection connect = null;
    
    public void connectDatabase(){
        try{
//            Class.forName("com.mysql.jdbc.Driver");
            connect = DriverManager.getConnection("jdbc:mysql://localhost/old_age_home","root","");
            System.out.println("Successfully Connected to Mysql");

        }catch(Exception e){
            System.out.println("Not Connected..");
            e.printStackTrace();
        }
    }
    
    
    public void insertData(String userIdText,String nameText, String passwordText,String conPassText){
        try{
            String query = "INSERT INTO user (userIdText, nameText,passwordText) values(?,?,?)";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, userIdText);
            pStatement.setString(2, nameText);
            pStatement.setString(3, passwordText);
           
            
            
            
            pStatement.executeUpdate();
            
            System.out.println("Successfully Inserted..");
            
            
        }catch(Exception e){
            System.out.println("Error in inserting");
            e.printStackTrace();
        }
        
     }
    
    public ResultSet testQuery(){
            ResultSet resultSet = null;
        try{
            String query = "SELECT * FROM user";
            Statement statement ;
            statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
 
            
            System.out.println("Successfully Done Query..");
           
        }catch(Exception e){
            System.out.println("Error in Query..");
            e.printStackTrace();
        }           
        return resultSet;
    }
    
 
    
    
}
